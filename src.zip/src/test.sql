SELECT TOP (10) [PersonnelNumber]
      ,[Firstname]
      ,[Lastname]
      ,[Email]
      ,[Site]
  FROM [ClearView_Automation].[dbo].[Test_Upload4]